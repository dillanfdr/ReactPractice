const getAllProductCategories = ()  => {
  return [   {
    id: 'FMEN',
    slug: 'men-shoes',
    name: `Men's Shoes`
  },
  {
    id: 'FWMEN',
    slug: 'women-shoes',
    name: `Women's Shoes`
  },
  ]
}

export default getAllProductCategories